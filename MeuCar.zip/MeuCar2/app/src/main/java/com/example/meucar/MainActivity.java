package com.example.meucar;

import android.os.Bundle;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText edtEmail, edtSenha;
    Button btnEntrar, btnCadastro;

    BancoDados banco;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        banco = new BancoDados(this);

        edtEmail = findViewById(R.id.edtEmail);
        edtSenha = findViewById(R.id.edtSenha);

        btnEntrar = findViewById(R.id.btnEntrar);
        btnCadastro = findViewById(R.id.btnCadastro);

        btnEntrar.setOnClickListener(v -> {

            String email = edtEmail.getText().toString().trim();
            String senha = edtSenha.getText().toString();

            if (email.isEmpty() || senha.isEmpty()) {

                Toast.makeText(this,
                        "Preencha todos os campos!",
                        Toast.LENGTH_SHORT).show();

                return;
            }

            int usuarioId = banco.login(email, senha);

            if (usuarioId != -1) {

                Intent intent = new Intent(
                        MainActivity.this,
                        TelaPrincipalActivity.class
                );

                intent.putExtra("usuario_id", usuarioId);

                startActivity(intent);
                finish();

            } else {

                Toast.makeText(this,
                        "E-mail ou senha incorretos!",
                        Toast.LENGTH_SHORT).show();
            }
        });

        btnCadastro.setOnClickListener(v -> {
            Intent intent = new Intent(
                    MainActivity.this,
                    CadastroActivity.class
            );

            startActivity(intent);
        });
    }
}