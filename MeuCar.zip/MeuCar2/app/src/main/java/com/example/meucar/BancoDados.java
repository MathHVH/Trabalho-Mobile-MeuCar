package com.example.meucar;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;
import java.util.ArrayList;

public class BancoDados extends SQLiteOpenHelper {

    private static final String BANCO = "GerenciamentoVeiculos.db";
    private static final int VERSAO = 1;

    public BancoDados(Context context) {
        super(context, BANCO, null, VERSAO);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(
                "CREATE TABLE usuarios (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "nome TEXT NOT NULL, " +
                        "email TEXT NOT NULL UNIQUE, " +
                        "senha TEXT NOT NULL)"
        );

        db.execSQL(
                "CREATE TABLE veiculos (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "placa TEXT NOT NULL, " +
                        "modelo TEXT NOT NULL, " +
                        "marca TEXT NOT NULL, " +
                        "ano INTEGER NOT NULL, " +
                        "cor TEXT NOT NULL, " +
                        "usuario_id INTEGER NOT NULL, " +
                        "FOREIGN KEY(usuario_id) REFERENCES usuarios(id))"
        );
    }

    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion
    ) {
        db.execSQL("DROP TABLE IF EXISTS veiculos");
        db.execSQL("DROP TABLE IF EXISTS usuarios");
        onCreate(db);
    }

    public boolean cadastrarUsuario(
            String nome,
            String email,
            String senha
    ) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues valores = new ContentValues();

        valores.put("nome", nome);
        valores.put("email", email);
        valores.put("senha", HashSenha.gerar(senha));

        long resultado = db.insert("usuarios", null, valores);

        return resultado != -1;
    }


    // REALIZAR LOGIN
    public int login(String email, String senha) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT id, senha FROM usuarios WHERE email = ?",
                new String[]{email}
        );

        int usuarioId = -1;

        if (cursor.moveToFirst()) {

            String senhaBanco = cursor.getString(1);

            if (HashSenha.verificar(senha, senhaBanco)) {
                usuarioId = cursor.getInt(0);
            }
        }

        cursor.close();

        return usuarioId;
    }


    // REGISTRAR VEICULO
    public boolean registrarVeiculo(
            String placa,
            String modelo,
            String marca,
            int ano,
            String cor,
            int usuarioId
    ) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues valores = new ContentValues();

        valores.put("placa", placa);
        valores.put("modelo", modelo);
        valores.put("marca", marca);
        valores.put("ano", ano);
        valores.put("cor", cor);
        valores.put("usuario_id", usuarioId);

        long resultado = db.insert("veiculos", null, valores);

        return resultado != -1;
    }


    // CONSULTAR VEICULOS DO USUARIO
    public ArrayList<String> consultarVeiculos(int usuarioId) {

        ArrayList<String> lista = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT id, placa, modelo, marca, ano, cor " +
                        "FROM veiculos WHERE usuario_id = ?",
                new String[]{String.valueOf(usuarioId)}
        );

        while (cursor.moveToNext()) {

            int id = cursor.getInt(0);
            String placa = cursor.getString(1);
            String modelo = cursor.getString(2);
            String marca = cursor.getString(3);
            int ano = cursor.getInt(4);
            String cor = cursor.getString(5);

            lista.add(
                    id + "|" +
                            "Placa: " + placa +
                            "\nModelo: " + modelo +
                            "\nMarca: " + marca +
                            "\nAno: " + ano +
                            "\nCor: " + cor
            );
        }

        cursor.close();

        return lista;
    }
    // EXCLUIR VEICULO
    public boolean excluirVeiculo(int veiculoId, int usuarioId) {

        SQLiteDatabase db = this.getWritableDatabase();

        int resultado = db.delete(
                "veiculos",
                "id = ? AND usuario_id = ?",
                new String[]{
                        String.valueOf(veiculoId),
                        String.valueOf(usuarioId)
                }
        );

        return resultado > 0;
    }
}