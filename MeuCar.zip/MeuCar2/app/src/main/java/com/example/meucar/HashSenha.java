package com.example.meucar;
import java.security.MessageDigest;
import java.security.SecureRandom;

public class HashSenha {

    public static String gerar(String senha) {
        try {
            byte[] salt = new byte[16];
            new SecureRandom().nextBytes(salt);

            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt);

            byte[] hash = md.digest(senha.getBytes("UTF-8"));

            return android.util.Base64.encodeToString(
                    salt, android.util.Base64.NO_WRAP
            ) + ":" +
                    android.util.Base64.encodeToString(
                            hash, android.util.Base64.NO_WRAP
                    );

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static boolean verificar(String senha, String armazenada) {
        try {
            String[] partes = armazenada.split(":");

            byte[] salt = android.util.Base64.decode(
                    partes[0], android.util.Base64.NO_WRAP
            );

            byte[] hashOriginal = android.util.Base64.decode(
                    partes[1], android.util.Base64.NO_WRAP
            );

            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt);

            byte[] hashDigitado = md.digest(senha.getBytes("UTF-8"));

            return MessageDigest.isEqual(hashOriginal, hashDigitado);

        } catch (Exception e) {
            return false;
        }
    }
}
