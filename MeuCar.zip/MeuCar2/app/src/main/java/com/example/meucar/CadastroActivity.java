package com.example.meucar;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CadastroActivity extends AppCompatActivity {

    EditText edtNome, edtEmail, edtSenha;
    Button btnCadastrar;

    BancoDados banco;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        banco = new BancoDados(this);

        edtNome = findViewById(R.id.edtNome);
        edtEmail = findViewById(R.id.edtEmail);
        edtSenha = findViewById(R.id.edtSenha);
        btnCadastrar = findViewById(R.id.btnCadastrar);

        btnCadastrar.setOnClickListener(v -> {

            String nome = edtNome.getText().toString().trim();
            String email = edtEmail.getText().toString().trim();
            String senha = edtSenha.getText().toString();

            if (nome.isEmpty() || email.isEmpty() || senha.isEmpty()) {

                Toast.makeText(this,
                        "Preencha todos os campos!",
                        Toast.LENGTH_SHORT).show();

            } else {

                boolean sucesso = banco.cadastrarUsuario(
                        nome, email, senha
                );

                if (sucesso) {

                    Toast.makeText(this,
                            "Cadastro realizado com sucesso!",
                            Toast.LENGTH_SHORT).show();

                    finish();

                } else {

                    Toast.makeText(this,
                            "Erro: e-mail já cadastrado ou dados inválidos!",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}