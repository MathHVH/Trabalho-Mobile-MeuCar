package com.example.meucar;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegistrarVeiculoActivity extends AppCompatActivity {

    EditText edtPlaca, edtModelo, edtMarca, edtAno, edtCor;
    Button btnSalvar;

    BancoDados banco;
    int usuarioId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar_veiculo);

        banco = new BancoDados(this);

        usuarioId = getIntent().getIntExtra("usuario_id", -1);

        edtPlaca = findViewById(R.id.edtPlaca);
        edtModelo = findViewById(R.id.edtModelo);
        edtMarca = findViewById(R.id.edtMarca);
        edtAno = findViewById(R.id.edtAno);
        edtCor = findViewById(R.id.edtCor);

        btnSalvar = findViewById(R.id.btnSalvarVeiculo);

        btnSalvar.setOnClickListener(v -> {

            String placa = edtPlaca.getText().toString().trim();
            String modelo = edtModelo.getText().toString().trim();
            String marca = edtMarca.getText().toString().trim();
            String anoTexto = edtAno.getText().toString().trim();
            String cor = edtCor.getText().toString().trim();

            if (placa.isEmpty() || modelo.isEmpty() ||
                    marca.isEmpty() || anoTexto.isEmpty() ||
                    cor.isEmpty()) {

                Toast.makeText(this,
                        "Preencha todos os campos!",
                        Toast.LENGTH_SHORT).show();

                return;
            }

            int ano;

            try {
                ano = Integer.parseInt(anoTexto);
            } catch (NumberFormatException e) {
                Toast.makeText(this,
                        "Ano inválido!",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            if (ano < 1886 || ano > 2100 || usuarioId == -1) {
                Toast.makeText(this,
                        "Verifique o ano ou o usuário!",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            boolean sucesso = banco.registrarVeiculo(
                    placa, modelo, marca, ano, cor, usuarioId
            );

            if (sucesso) {

                Toast.makeText(this,
                        "Veículo registrado com sucesso!",
                        Toast.LENGTH_SHORT).show();

                finish();

            } else {

                Toast.makeText(this,
                        "Erro ao registrar veículo!",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}