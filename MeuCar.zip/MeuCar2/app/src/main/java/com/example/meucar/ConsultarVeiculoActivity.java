package com.example.meucar;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import android.app.AlertDialog;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ConsultarVeiculoActivity extends AppCompatActivity {

    ListView listaVeiculos;

    BancoDados banco;
    int usuarioId;

    ArrayList<Integer> idsVeiculos;
    ArrayList<String> nomesVeiculos;

    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consultar_veiculo);

        banco = new BancoDados(this);

        usuarioId = getIntent().getIntExtra("usuario_id", -1);

        listaVeiculos = findViewById(R.id.listaVeiculos);

        idsVeiculos = new ArrayList<>();
        nomesVeiculos = new ArrayList<>();

        adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                nomesVeiculos
        );

        listaVeiculos.setAdapter(adapter);

        atualizarLista();

        // Selecionar veículo para excluir
        listaVeiculos.setOnItemClickListener((parent, view, position, id) -> {

            int veiculoId = idsVeiculos.get(position);

            new AlertDialog.Builder(this)
                    .setTitle("Excluir veículo")
                    .setMessage(
                            "Deseja realmente excluir este veículo?"
                    )
                    .setPositiveButton("Excluir", (dialog, which) -> {

                        boolean sucesso = banco.excluirVeiculo(
                                veiculoId,
                                usuarioId
                        );

                        if (sucesso) {

                            Toast.makeText(this,
                                    "Veículo excluído com sucesso!",
                                    Toast.LENGTH_SHORT).show();

                            atualizarLista();

                        } else {

                            Toast.makeText(this,
                                    "Erro ao excluir veículo!",
                                    Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
        });
    }

    // ATUALIZAR LISTA DE VEICULOS
    private void atualizarLista() {

        idsVeiculos.clear();
        nomesVeiculos.clear();

        ArrayList<String> veiculos =
                banco.consultarVeiculos(usuarioId);

        for (String veiculo : veiculos) {

            int separador = veiculo.indexOf("|");

            if (separador != -1) {

                int id = Integer.parseInt(
                        veiculo.substring(0, separador)
                );

                String informacoes = veiculo.substring(
                        separador + 1
                );

                idsVeiculos.add(id);
                nomesVeiculos.add(informacoes);
            }
        }

        adapter.notifyDataSetChanged();
    }
}