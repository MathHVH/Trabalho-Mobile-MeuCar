package com.example.meucar;

import android.os.Bundle;
import android.content.Intent;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class TelaPrincipalActivity extends AppCompatActivity {

    Button btnRegistrar, btnConsultar;
    int usuarioId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_principal);

        usuarioId = getIntent().getIntExtra("usuario_id", -1);

        btnRegistrar = findViewById(R.id.btnRegistrar);
        btnConsultar = findViewById(R.id.btnConsultar);

        btnRegistrar.setOnClickListener(v -> {

            Intent intent = new Intent(
                    this, RegistrarVeiculoActivity.class
            );

            intent.putExtra("usuario_id", usuarioId);
            startActivity(intent);
        });

        btnConsultar.setOnClickListener(v -> {

            Intent intent = new Intent(
                    this, ConsultarVeiculoActivity.class
            );

            intent.putExtra("usuario_id", usuarioId);
            startActivity(intent);
        });
    }
}
